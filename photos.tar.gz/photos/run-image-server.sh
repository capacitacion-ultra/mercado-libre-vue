RUTA=$PWD

docker stop image-server
docker rm image-server

docker run -d \
-p 8888:80 \
-v $RUTA:/usr/share/nginx/html \
--name image-server \
nginx

